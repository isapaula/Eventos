@extends('layouts.main')

@section('title', 'HBC Events')

@section('content')

        <h1>Dashboard</h1>

        <div id="search-container" class="col-md-12">
          <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
              <div class="carousel-item active">
                <h1>Busque um evento</h1>
                <form action="/" method="GET">
                  <input type="text" id="search" name="search" class="form-control" placeholder="Procurar...">
                </form>
              </div>
            </div>
          </div>  
        </div>
        <div id="events-container" class="col-md-12">
          @if($search)
           <h2>Buscando por: {{ $search }} </h2>
          @else
          <h2>Proximos Eventos</h2>
          @endif
          <p>Veja os eventos dos proximos dias. </p>
          <div id="cards-container" class="row">
              @foreach($events as $event)
                  <div class="card col-md-3" style="margin: 20px;">  
                    <div class="card-body">
                      <img width="60" height="50" src="/img/events/{{ $event->image }}" alt="{{ $event->image }}">
                      <div class="card-title"><h5>{{ $event->title }}</h5></div>
                      <div class="card-date"> <p>{{ date('d/m/Y', strtotime($event->data)) }}</p></div>
                      <p class="event-city"> {{ count($event->users) }} participantes</p>
                     <a href="/events/{{$event->id}}" class="btn btn-secondary">Saiba mais</a> 
                    
                    </div>
                  </div>
              @endforeach
              @if(count($events) == 0)
                <h4>Nao há eventos <a href="/">Ver todos!</a></h4>
              @endif
          </div>
        </div>

@endsection        

