@extends('layouts.main')

@section('title', 'Editando: '. $event->title)

@section('content')
<br>
<h1 style="text-align: center; margin-top: 10px;">Editando:  {{ $event->title }}</h1>
<br>

<div id="event-create-container" class="col-md-6 offset-md-3">
<form action="/events/update/{{ $event->id }}" method="POST" enctype="multipart/form-data" style="padding-left: 50px; padding-right: 50px;">
  <br>
   @csrf
   @method('PUT')
   <div class="form-group">
      <label class="form-label" for="image">Imagem do Evento:</label>
      <input type="file" class="form-control-file" id="image" name="image">
      <img src="/img/events/{{ $event->image }}" alt="{{ $event->image }}" class="img-preview">
    </div>
    <div class="form-group">
      <label class="form-label" for="title">Evento:</label>
      <input type="text" class="form-control" id="title" name="title" placeholder="Nome do evento" value="{{ $event->title }}">
    </div>
    <div class="form-group">
      <label for="data" class="form-label">Data do Evento:</label>
      <input type="date" class="form-control" id="data" name="data" value="{{ $event->data }} ">
    </div>
    <div class="form-group">
      <label  class="form-label" for="description">Descrição:</label>
      <textarea class="form-control" name="description" id="description" cols="30" rows="2" placeholder="Descrição..." value="">{{ $event->description }}</textarea>
    </div>
    <br>
    <div class="form-group">
      <label  class="form-label" for="itens">Adicione items:</label>
     <div class="form-check form-check-inline">
        <input type="checkbox" name="itens[]" value="cadeiras">
        <label for="">Cadeiras</label>
     </div>
     <div class="form-check form-check-inline">
        <input type="checkbox" name="itens[]" value="microfone">
        <label for="">microfone</label>
     </div>
     <div class="form-check form-check-inline">
        <input type="checkbox" name="itens[]" value="som">
        <label for="">som</label>
     </div>
    </div>
    <div class="form-group">
      <label class="form-label" for="city">Cidade:</label>
      <input type="text" class="form-control" id="city" name="city" placeholder="Nome da cidade" value="{{ $event->city }}">
    </div>
    <div class="form-group">
      <label class="form-label" for="private">O Evento é privado?</label>
      <select  class="form-select" aria-label="Default select example" name="private" id="private" >
        <option value="0">Não</option>
        <option value="1" {{ $event->private == 1 ? "selected = 'selected' " : " " }}>Sim</option>
      </select>
    </div>
    <br>
    <div class="form-group">
      <input type="submit" class="btn btn-primary" value="Crie o Evento">
    </div>
</form>
</div>

@endsection   