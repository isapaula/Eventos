@extends('layouts.main')

@section('title', 'Criar Evento')

@section('content')
<br>
<h1 style="text-align: center; margin-top: 10px;">Crie um evento </h1>
<br>

<div id="event-create-container" class="col-md-6 offset-md-3">
<form action="/events" method="POST" enctype="multipart/form-data" style="padding-left: 50px; padding-right: 50px; height: auto;">
  <br>
   @csrf
   <div class="form-group">
      <label class="form-label" for="image">Imagem do Evento:</label>
      <input type="file" class="form-control-file" id="image" name="image">
    </div>
    <div class="form-group">
      <label class="form-label" for="title">Evento:</label>
      <input type="text" class="form-control" id="title" name="title" placeholder="Nome do evento">
    </div>
    <div class="form-group">
      <label for="data" class="form-label">Data do Evento:</label>
      <input type="date" class="form-control" id="data" name="data">
    </div>
    <div class="form-group">
      <label  class="form-label" for="description">Descrição:</label>
      <textarea class="form-control" name="description" id="description" cols="30" rows="2" placeholder="Descrição..."></textarea>
    </div>
    <br>
    <div class="form-group">
      <label  class="form-label" for="itens">Adicione items:</label>
     <div class="form-check form-check-inline">
        <input type="checkbox" name="itens[]" value="cadeiras">
        <label for="">Cadeiras</label>
     </div>
     <div class="form-check form-check-inline">
        <input type="checkbox" name="itens[]" value="microfone">
        <label for="">microfone</label>
     </div>
     <div class="form-check form-check-inline">
        <input type="checkbox" name="itens[]" value="som">
        <label for="">som</label>
     </div>
    </div>
    <div class="form-group">
      <label class="form-label" for="city">Cidade:</label>
      <input type="text" class="form-control" id="city" name="city" placeholder="Nome da cidade">
    </div>
    <div class="form-group">
      <label class="form-label" for="private">O Evento é privado?</label>
      <select  class="form-select" aria-label="Default select example" name="private" id="private" >
        <option value="0">Não</option>
        <option value="1">Sim</option>
      </select>
    </div>
    <br>
    <div class="form-group">
      <input type="submit" class="btn btn-primary" value="Crie o Evento">
    </div>
</form>
</div>

@endsection   