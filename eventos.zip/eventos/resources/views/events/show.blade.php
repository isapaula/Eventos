@extends('layouts.main')

@section('title', $event->title)

@section('content')

 <div id="show-container" class="col-md-10 offset-md-1">
    <div class="row">
        <div id="image-container" class="col-md-6">
            <img width="100" height="100" src="/img/events/{{ $event->image}}" alt="">
        </div>
        <div id="info-container" class="col-md-6">
            <h1>{{ $event->title }}</h1>
            <p class="event-city"><ion-icon name="location-outline"></ion-icon> {{ $event->city }}</p>
            @if(!$hasUserJoin)
                <form action="/events/join/{{ $event->id }}" method="post">
                @csrf
                    <a href="/events/join/{{ $event->id }}"
                    id="event.submit"
                    onclick="event.preventDefault();
                    this.closest('form').submit();" 
                    class="btn btn-dark">Confirmar presença</a>
                </form>
            @else
                <div class="alert alert-warning" role="alert">
                    Você já esta participando desse evento!
                </div>

            @endif
          
            <p class="event-city"> {{ count($event->users) }} participantes</p>
            <p>{{ $eventower['name'] }}</p>
            <p class="card-date">{{ date('d/m/Y', strtotime($event->data)) }}</p>
            <p class="event-desc">{{ $event->description }}</p>
            @if($event->itens != 0)
                <h3>O Evento tem :</h3>
                <ul id="items-list">
                    @foreach($event->itens as $item)
                        <li><span>{{ $item }}</span></li>
                    @endforeach
                </ul>
            @endif
        </div>
    </div>
 </div>

@endsection   