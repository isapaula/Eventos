@extends('layouts.main')

@section('title', 'HBC Dashboard')

@section('content')



<div class="col-md-10 offset-md-1 dashboard-events-container">
<div class="col-md-10 offset-md-1 dashboard-title-container">
    <h1>Meus Eventos</h1>
</div>
<br>
    @if(count($events) > 0)
    <table class="table">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Titulo</th>
                <th scope="col">Participantes</th>
                <th scope="col">Data</th>
                <th scope="col">Ações</th>
            </tr>
        </thead>
        <tbody>
            @foreach($events as $event)
                <tr>
                    <th scope="row">{{ $loop->index +1 }}</th>
                    <td><a href="/events/{{ $event->id }}">{{ $event->title }}</a></td>
                    <td>{{ count($event->users) }}</td>
                    <td>{{ date('d/m/Y', strtotime($event->data)) }}</td>
                    <td><a href="/events/edit/{{ $event->id }}"  class="btn btn-warning">Editar</a>
                    <form action="/events/{{ $event->id }}" method="POST">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger">Excluir</button>
                    </form>
                </td>
                </tr>
            @endforeach    
        </tbody>
    </table>
    @else
        <p>Voce ainda nao tem eventos <a href="/events/create">criar eventos</a></p>
    @endif

</div>

<div class="col-md-10 offset-md-1 dashboard-events-container">
<div class="col-md-10 offset-md-1 dashboard-title-container">
    <h1>Eventos que estou participando</h1>
</div>
<br>
    @if(count($eventsAsParticipant) > 0 )
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Titulo</th>
                    <th scope="col">Participantes</th>
                    <th scope="col">Data</th>
                    <th scope="col">Ações</th>
                </tr>
            </thead>
            <tbody>
                @foreach($eventsAsParticipant as $event)
                    <tr>
                        <th scope="row">{{ $loop->index +1 }}</th>
                        <td><a href="/events/{{ $event->id }}">{{ $event->title }}</a></td>
                        <td>{{ count($event->users) }}</td>
                        <td>{{ date('d/m/Y', strtotime($event->data)) }}</td>
                        <td>
                            <form action="/events/leave/{{ $event->id }}" method="post">
                                @csrf
                                @method('DELETE')
                               <button type="submit" class="btn btn-light">Sair do Evento</button> 
                            </form>
                        </td>
                    </tr>
                @endforeach    
            </tbody>
        </table>
    @else
        <p>Voce nao esta participando de nenhum evento</p><a href="">Vert todos os eventos</a>  
    @endif
</div>    

@endsection    
