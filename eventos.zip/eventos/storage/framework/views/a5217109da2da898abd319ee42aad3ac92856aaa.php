

<?php $__env->startSection('title', $event->title); ?>

<?php $__env->startSection('content'); ?>

 <div id="show-container" class="col-md-10 offset-md-1">
    <div class="row">
        <div id="image-container" class="col-md-6">
            <img width="100" height="100" src="/img/events/<?php echo e($event->image); ?>" alt="">
        </div>
        <div id="info-container" class="col-md-6">
            <h1><?php echo e($event->title); ?></h1>
            <p class="event-city"><ion-icon name="location-outline"></ion-icon> <?php echo e($event->city); ?></p>
            <?php if(!$hasUserJoin): ?>
                <form action="/events/join/<?php echo e($event->id); ?>" method="post">
                <?php echo csrf_field(); ?>
                    <a href="/events/join/<?php echo e($event->id); ?>"
                    id="event.submit"
                    onclick="event.preventDefault();
                    this.closest('form').submit();" 
                    class="btn btn-dark">Confirmar presença</a>
                </form>
            <?php else: ?>
                <div class="alert alert-warning" role="alert">
                    Você já esta participando desse evento!
                </div>

            <?php endif; ?>
          
            <p class="event-city"> <?php echo e(count($event->users)); ?> participantes</p>
            <p><?php echo e($eventower['name']); ?></p>
            <p class="card-date"><?php echo e(date('d/m/Y', strtotime($event->data))); ?></p>
            <p class="event-desc"><?php echo e($event->description); ?></p>
            <?php if($event->itens != 0): ?>
                <h3>O Evento tem :</h3>
                <ul id="items-list">
                    <?php $__currentLoopData = $event->itens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><span><?php echo e($item); ?></span></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>
 </div>

<?php $__env->stopSection(); ?>   
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cursolaravel\hdcevents\resources\views/events/show.blade.php ENDPATH**/ ?>