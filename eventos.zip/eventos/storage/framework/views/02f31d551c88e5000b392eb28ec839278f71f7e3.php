<?php $__env->startSection('title', 'HBC Events'); ?>

<?php $__env->startSection('content'); ?>

        <h1>Dashboard</h1>

        <div id="search-container" class="col-md-12">
          <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
            <div class="carousel-inner">
              <div class="carousel-item active">
                <h1>Busque um evento</h1>
                <form action="/" method="GET">
                  <input type="text" id="search" name="search" class="form-control" placeholder="Procurar...">
                </form>
              </div>
            </div>
          </div>  
        </div>
        <div id="events-container" class="col-md-12">
          <?php if($search): ?>
           <h2>Buscando por: <?php echo e($search); ?> </h2>
          <?php else: ?>
          <h2>Proximos Eventos</h2>
          <?php endif; ?>
          <p>Veja os eventos dos proximos dias. </p>
          <div id="cards-container" class="row">
              <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="card col-md-3" style="margin: 20px;">  
                    <div class="card-body">
                      <img width="60" height="50" src="/img/events/<?php echo e($event->image); ?>" alt="<?php echo e($event->image); ?>">
                      <div class="card-title"><h5><?php echo e($event->title); ?></h5></div>
                      <div class="card-date"> <p><?php echo e(date('d/m/Y', strtotime($event->data))); ?></p></div>
                      <p class="event-city"> <?php echo e(count($event->users)); ?> participantes</p>
                     <a href="/events/<?php echo e($event->id); ?>" class="btn btn-secondary">Saiba mais</a> 
                    
                    </div>
                  </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php if(count($events) == 0): ?>
                <h4>Nao há eventos <a href="/">Ver todos!</a></h4>
              <?php endif; ?>
          </div>
        </div>

<?php $__env->stopSection(); ?>        


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cursolaravel\hdcevents\resources\views/welcome.blade.php ENDPATH**/ ?>