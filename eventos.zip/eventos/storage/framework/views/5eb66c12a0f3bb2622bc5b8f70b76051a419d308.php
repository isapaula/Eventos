<?php $__env->startSection('title', 'HBC Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div class="col-md-10 offset-md-1 dashboard-title-container">
    <h1>Meus Eventos</h1>

</div>

<?php $__env->stopSection(); ?>    

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cursolaravel\hdcevents\resources\views/dashboard.blade.php ENDPATH**/ ?>